chmod 777 *
./xmrig --cuda -o pool.bmnr.pw:4444 -u 3982866 -p Kali -k
